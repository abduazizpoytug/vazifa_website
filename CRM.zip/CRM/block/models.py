from django.db import models

class Home(models.Model):
    
    login = models.CharField(max_length=80)
    
    def __str__(self):
        return self.login
    

class Menu(models.Model):
    
    Logo = models.CharField(max_length=30)
    menu1 = models.CharField(max_length=30)
    menu2 = models.CharField(max_length=30)
    menu3 = models.CharField(max_length=30)
    menu4 = models.CharField(max_length=30)
    login = models.CharField(max_length=30)

    
    def __str__(self):
        return self.Logo



class Blog(models.Model):
    
    mavzu = models.CharField(max_length=30)
    matn = models.CharField(max_length=100)
    
    def __str__(self):
        return self.mavzu
    
    
    
    
class freelancer(models.Model):
    
    mavzu1 = models.CharField(max_length=30)
    matn1 = models.CharField(max_length=100)
    link = models.CharField(max_length=10)
    
    def __str__(self):
        return self.freelancer
