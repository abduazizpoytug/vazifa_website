from multiprocessing import context
from django.shortcuts import redirect, render, reverse
from django.views import generic
from .models import *
from .forms import Registration
    

class Register(generic.CreateView):
    template_name = 'registration/signup.html'
    form_class = Registration
    
    def get_success_url(self):
        return reverse('django:home')

def home(request):
   
    home = Menu.objects.all()
    blog = Blog.objects.all()
    computer = freelancer.objects.all()
    context = {
        "home":home,
        "blog":blog,
        "computer":computer,
    }
    
    return render(request, 'index.html', context)




# def blog(request):
   
#     blog = Blog.objects.all()
#     context = {
#         "blog":blog
#     }
    
